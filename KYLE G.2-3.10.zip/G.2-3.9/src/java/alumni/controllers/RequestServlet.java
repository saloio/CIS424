/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package alumni.controllers;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

import alumni.business.User;
import alumni.data.*;


public class RequestServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession();

        String url = "/home/requests.jsp";

        // get current action
        String action = request.getParameter("action");
        if (action == null) {
            action = "view";  // default action
        }

        // perform action and set URL to appropriate page
        if (action.equals("view")) {
            // get list of users
            String message = "";
            
            User user = (User) session.getAttribute("user");
            Long id = user.getId();
            User request_user = RelationshipDB.checkRequest(id);
            Long rqst_userid = request_user.getFriendUserID();

            request_user = UserDB.selectUser(rqst_userid);

            request.setAttribute("request_user", request_user);

            url = "/home/requests.jsp";

        } else if (action.equals("accept")) {
            // get
            User user = (User) session.getAttribute("user");
            Long id = user.getId();
            User request_user = RelationshipDB.checkRequest(id);
            Long rqst_userid = request_user.getFriendUserID();
            request_user = UserDB.selectUser(rqst_userid);

            RelationshipDB.acceptNetwork(user, request_user);

            request.setAttribute("request_user", request_user);

            url = "/home/requests.jsp";

        } else if (action.equals("decline")) {
            // get
            User user = (User) session.getAttribute("user");
            Long id = user.getId();
            User request_user = RelationshipDB.checkRequest(id);
            Long rqst_userid = request_user.getFriendUserID();
            request_user = UserDB.selectUser(rqst_userid);

            RelationshipDB.declineNetwork(user, request_user);

            request.setAttribute("request_user", request_user);

            url = "/home/requests.jsp";
        }

        getServletContext()
                .getRequestDispatcher(url)
                .forward(request, response);
    }

    @Override
    protected void doGet(HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {
        doPost(request, response);
    }

}
