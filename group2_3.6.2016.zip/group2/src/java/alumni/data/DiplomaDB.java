package alumni.data;

/**
 *
 * @author Sandro
 */
import java.sql.*;
import alumni.business.Diploma;

public class DiplomaDB {

    public static void insert(Diploma diploma) {
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;

        String query
                = "INSERT INTO diploma_t (graduation_year, degree, major) "
                + "VALUES (?, ?, ?)";
        try {
            ps = connection.prepareStatement(query);
            ps.setInt(1, diploma.getYear());
            ps.setString(2, diploma.getDegree());
            ps.setString(3, diploma.getMajor());
            
            ps.executeUpdate();

        } catch (SQLException e) {
            System.out.println(e);

        } finally {
            DBUtil.closeResultSet(rs);
            DBUtil.closePreparedStatement(ps);
            pool.freeConnection(connection);
        }
    }
}