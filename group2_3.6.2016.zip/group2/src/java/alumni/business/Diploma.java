/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package alumni.business;

/**
 *
 * @author Sandro
 */
import java.io.Serializable;

public class Diploma implements Serializable {

    private String major;
    private String degree;
    private int year;


    public Diploma(int year, String degree, String major) {
        this.year = year;
        this.degree = degree;
        this.major = major;
    }

    public String getMajor() {
        return major;
    }

    public void setMajor(String major) {
        this.major = major;
    }

    public String getDegree() {
        return degree;
    }

    public void setDegree(String degree) {
        this.degree = degree;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

}
