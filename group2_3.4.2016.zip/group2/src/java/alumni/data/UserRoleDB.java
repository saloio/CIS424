/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package alumni.data;

/**
 *
 * @author Sandro
 */
import java.sql.*;
import alumni.business.*;
public class UserRoleDB {
    public static long insert(Role role) {
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;

        String query = "INSERT INTO userrole_t "
                + "(Email, Rolename) "
                + "VALUES "
                + "(?, 'alumnus')";
        try {
            ps = connection.prepareStatement(query);
            ps.setString(1, role.getEmail());
            return ps.executeUpdate();
        } catch (SQLException e) {
            System.err.println(e);
            return 0;
        } finally {
            DBUtil.closeResultSet(rs);
            DBUtil.closePreparedStatement(ps);
            pool.freeConnection(connection);
        }
    }
}