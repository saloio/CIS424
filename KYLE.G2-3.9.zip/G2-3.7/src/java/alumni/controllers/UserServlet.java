/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package alumni.controllers;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

import alumni.business.User;
import alumni.data.UserDB;
import java.util.ArrayList;

public class UserServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession();

        String url = "/home/search.jsp";

        // get current action
        String action = request.getParameter("action");
        if (action == null) {
            action = "search_users";  // default action
        }

        // perform action and set URL to appropriate page
        if (action.equals("search_users")) {
            // get list of users
            String fname = request.getParameter("fname");
            String lname = request.getParameter("lname");
            String lnamediploma = request.getParameter("lnamediploma");
            String major = request.getParameter("major");
            String degree = request.getParameter("degree");
            String year1 = request.getParameter("year1");
            String year2 = request.getParameter("year2");

            String[] sqlArray = {fname, lname, lnamediploma, major, degree, year1, year2};

            ArrayList<User> users = UserDB.findUsers(sqlArray);
            request.setAttribute("users", users);

            url = "/home/search.jsp";

        } else if (action.equals("view_alumni")) {
            // get
            String email = request.getParameter("email");
            User view = UserDB.selectUser(email);
            request.setAttribute("view", view);

            url = "/home/view_friend_info.jsp";

        } else if (action.equals("update_user")) {
            // get parameters from the request
            String password = request.getParameter("password");

            // get and update user
            User user = (User) session.getAttribute("userUpdate");
            user.setPassword(password);
            request.setAttribute("user", user);

        } else if (action.equals("delete_user")) {
            // get the user
            String email = request.getParameter("email");
            User userDelete = UserDB.selectUser(email);

            // delte the user
            UserDB.delete(userDelete);

            User user = UserDB.selectUser(email);
            request.setAttribute("user", user);
        }

        getServletContext()
                .getRequestDispatcher(url)
                .forward(request, response);
    }

    @Override
    protected void doGet(HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {
        doPost(request, response);
    }

}
