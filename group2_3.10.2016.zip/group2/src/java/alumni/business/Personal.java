/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package alumni.business;

/**
 *
 * @author Sandro
 */
import java.io.InputStream;
import java.io.Serializable;

public class Personal implements Serializable {

    private User user;
    private Long userId;
    private String cellphone;
    private String self_description;
    private InputStream photos;

    public Personal() {
        user = null;
        cellphone = "";
        self_description = "";
        photos = null;
    }

    public Long getId() {
        return userId;
    }

    public void setId(Long userId) {
        this.userId = userId;
    }

    public InputStream getPhotos() {
        return photos;
    }

    public void setPhotos(InputStream photos) {
        this.photos = photos;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public User getUser() {
        return user;
    }

    public String getCellphone() {
        return cellphone;
    }

    public void setCellphone(String cellphone) {
        this.cellphone = cellphone;
    }

    public String getSelf_description() {
        return self_description;
    }

    public void setSelf_description(String self_description) {
        this.self_description = self_description;
    }

}
