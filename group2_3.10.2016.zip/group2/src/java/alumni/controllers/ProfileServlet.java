/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package alumni.controllers;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

/**
 *
 * @author Sandro
 */
import alumni.business.*;
import alumni.data.*;
import alumni.util.*;
import java.util.ArrayList;
import java.util.Arrays;
import javax.servlet.annotation.MultipartConfig;

@MultipartConfig(maxFileSize = 16177215)    // upload file's size up to 16M
public class ProfileServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {
        String url = "/index.html";

        // get current action
        String action = request.getParameter("action");
        if (action == null) {
            action = "join";  // default action
        }

        // perform action and set URL to appropriate page
        if (action.equals("join")) {
            url = "/signup.jsp";    // the "join" page
        } else if (action.equals("personal")) {
            // get parameters from the request
            url = personalUser(request, response);
        } else if (action.equals("employer")) {
            // get parameters from the request
            url = employerUser(request, response);
        } else if (action.equals("diplomas")) {
            // get parameters from the request
            url = diplomasUser(request, response);
        } else if (action.equals("skills")) {
            // get parameters from the request
            url = skillsUser(request, response);
        }
        getServletContext()
                .getRequestDispatcher(url)
                .forward(request, response);
    }

    private String personalUser(HttpServletRequest request,
            HttpServletResponse response) throws IOException, ServletException {

        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");

        // if the User object doesn't exist, check for the email cookie
        if (user == null) {
            Cookie[] cookies = request.getCookies();
            String emailAddress
                    = CookieUtil.getCookieValue(cookies, "emailCookie");
            // if the email cookie doesn't exist, go to the registration page
            if (emailAddress == null || emailAddress.equals("")) {
                return "/index.jsp";
            } else {
                user = UserDB.selectUser(emailAddress);
                // if a user for that email isn't in the database, 
                // go to the registration page
                if (user == null) {
                    return "/index.jsp";
                }
                session.setAttribute("user", user);
            }
        }
        String cellphone = request.getParameter("cellphone");
        String self_description = request.getParameter("self_description");
        //InputStream inputStream = null; // input stream of the upload file
        // obtains the upload file part in this multipart request
        Part filePart = request.getPart("photos");

        InputStream inputStream = filePart.getInputStream();

        Long userID = user.getId();

        Personal personal;
        if (PersonalDB.PersonalExists(userID)) {
            personal = PersonalDB.selectUser(userID);
            personal.setUser(user);
            personal.setCellphone(cellphone);
            personal.setSelf_description(self_description);
            personal.setPhotos(inputStream);
            PersonalDB.update(personal);
            PersonalDB.insertPhoto(personal);
        } else {
            personal = new Personal();
            personal.setUser(user);
            personal.setCellphone(cellphone);
            personal.setSelf_description(self_description);
            personal.setPhotos(inputStream);
            PersonalDB.insert(personal);
            PersonalDB.insertPhoto(personal);
        }
        session.setAttribute("personal", personal);
        return "/home/edit.jsp";
    }

    private String employerUser(HttpServletRequest request,
            HttpServletResponse response) {

        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");

        // if the User object doesn't exist, check for the email cookie
        if (user == null) {
            Cookie[] cookies = request.getCookies();
            String emailAddress
                    = CookieUtil.getCookieValue(cookies, "emailCookie");
            // if the email cookie doesn't exist, go to the registration page
            if (emailAddress == null || emailAddress.equals("")) {
                return "/index.jsp";
            } else {
                user = UserDB.selectUser(emailAddress);
                // if a user for that email isn't in the database, 
                // go to the registration page
                if (user == null) {
                    return "/index.jsp";
                }
                session.setAttribute("user", user);
            }
        }
        String employer = request.getParameter("employer");
        String position = request.getParameter("position");
        String workphone = request.getParameter("workphone");
        Long userID = user.getId();

        Employment employment;
        if (EmploymentDB.EmployerExists(userID)) {
            employment = EmploymentDB.selectUser(userID);
            employment.setUser(user);
            employment.setWorkphone(workphone);
            employment.setEmployer(employer);
            employment.setPosition(position);
            EmploymentDB.update(employment);
        } else {
            employment = new Employment();
            employment.setUser(user);
            employment.setWorkphone(workphone);
            employment.setEmployer(employer);
            employment.setPosition(position);
            EmploymentDB.insert(employment);
        }
        session.setAttribute("employment", employment);
        return "/home/edit.jsp";
    }

    private String diplomasUser(HttpServletRequest request,
            HttpServletResponse response) {

        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");

        // if the User object doesn't exist, check for the email cookie
        if (user == null) {
            Cookie[] cookies = request.getCookies();
            String emailAddress
                    = CookieUtil.getCookieValue(cookies, "emailCookie");
            // if the email cookie doesn't exist, go to the registration page
            if (emailAddress == null || emailAddress.equals("")) {
                return "/index.jsp";
            } else {
                user = UserDB.selectUser(emailAddress);
                // if a user for that email isn't in the database, 
                // go to the registration page
                if (user == null) {
                    return "/index.jsp";
                }
                session.setAttribute("user", user);
            }
        }
        int year = Integer.parseInt(request.getParameter("year"));
        String degree = request.getParameter("degree");
        String major = request.getParameter("major");

        Diplomas diplomas = new Diplomas();
        diplomas.setUser(user);
        diplomas.setYear(year);
        diplomas.setDegree(degree);
        diplomas.setMajor(major);
        DiplomasDB.insert(diplomas);
        session.setAttribute("diplomas", diplomas);
        return "/home/edit.jsp";
    }

    private String skillsUser(HttpServletRequest request,
            HttpServletResponse response) {

        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");

        // if the User object doesn't exist, check for the email cookie
        if (user == null) {
            Cookie[] cookies = request.getCookies();
            String emailAddress
                    = CookieUtil.getCookieValue(cookies, "emailCookie");
            // if the email cookie doesn't exist, go to the registration page
            if (emailAddress == null || emailAddress.equals("")) {
                return "/index.jsp";
            } else {
                user = UserDB.selectUser(emailAddress);
                // if a user for that email isn't in the database, 
                // go to the registration page
                if (user == null) {
                    return "/index.jsp";
                }
                session.setAttribute("user", user);
            }
        }
        String[] checkboxValues = request.getParameterValues("skills");
        Long userID = user.getId();
        String skillsValues = Arrays.toString(checkboxValues)
                .replace("[", "") //remove the right bracket
                .replace("]", "") //remove the left bracket
                .trim();

        Skills skills;
        if (SkillsDB.SkillsExists(userID)) {
            skills = SkillsDB.selectUser(userID);
            skills.setUser(user);
            skills.setSkills(skillsValues);
            SkillsDB.update(skills);
        } else {
            skills = new Skills();
            skills.setUser(user);
            skills.setSkills(skillsValues);
            SkillsDB.insert(skills);
        }
        session.setAttribute("skills", skillsValues);
        return "/home/edit.jsp";
    }

    private String networkList(HttpServletRequest request,
            HttpServletResponse response) {

        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");

        // if the User object doesn't exist, check for the email cookie
        if (user == null) {
            Cookie[] cookies = request.getCookies();
            String emailAddress
                    = CookieUtil.getCookieValue(cookies, "emailCookie");
            // if the email cookie doesn't exist, go to the registration page
            if (emailAddress == null || emailAddress.equals("")) {
                return "/index.jsp";
            } else {
                user = UserDB.selectUser(emailAddress);
                // if a user for that email isn't in the database, 
                // go to the registration page
                if (user == null) {
                    return "/index.jsp";
                }
                session.setAttribute("user", user);
            }
        }

        ArrayList<User> networks_ = RelationshipDB.networkList_one(user);
        ArrayList<User> networks = RelationshipDB.networkList_two(user);
        
        //networks.addAll(networksTwo);
        
        request.setAttribute("networks", networks);

        return "/home/networks.jsp";
    }
}
