/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package alumni.controllers;

import alumni.business.Diplomas;
import alumni.business.Employment;
import alumni.business.Personal;
import alumni.business.Skills;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

import alumni.business.User;
import alumni.data.*;
import java.util.ArrayList;

public class SearchServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession();

        String url = "/home/search.jsp";

        // get current action
        String action = request.getParameter("action");
        if (action == null) {
            action = "search_users";  // default action
        }

        // perform action and set URL to appropriate page
        if (action.equals("search_users")) {

            // get list of users
            String getFname = request.getParameter("fname");
            String getLname = request.getParameter("lname");
            String getLnamediploma = request.getParameter("lnamediploma");
            String getMajor = request.getParameter("major");
            String getDegree = request.getParameter("degree");
            String getYear1 =  request.getParameter("year1");
            String getYear2 = request.getParameter("year2s");

            String fname = "";
            String lname = "";
            String lnamediploma = "";
            String major = "";
            String degree = "";
            String year = "";

            String c1 = "";
            String c2 = "";
            String c3 = "";
            String c4 = "";
            String c5 = "";

            //Fname Checkbox
            if (request.getParameter("check_fname") != null) {
                if (getFname != "") {
                    fname = "fname = " + "'"
                            + request.getParameter("fname") + "'";
                }
            }

            //Lname Checkbox
            if (request.getParameter("check_lname") != null) {
                if (getFname != "") {
                    c1 = " AND ";
                }
                if (request.getParameter("lname") != "") {
                    lname = "lname = " + "'"
                            + request.getParameter("lname") + "'";
                }
            }

            //Lnamediploma Checkbox
            if (request.getParameter("check_lnamediploma") != null) {
                if (getFname != "" || getLname != "") {
                    c2 = " AND ";
                }
                if (getLnamediploma != "") {
                    lnamediploma = "lnamediploma = " + "'"
                            + request.getParameter("lnamediploma") + "'";
                }
            }

            //Major Checkbox
            if (request.getParameter("check_major") != null) {
                if (getFname != "" || getLname != "" || getLnamediploma != "") {
                    c3 = " AND ";
                }
                if (getMajor != "") {
                    major = "major = " + "'"
                            + request.getParameter("major") + "'";
                }
            }

            //Degree Checkbox
            if (request.getParameter("check_degree") != null) {
                if (getFname != "" || getLname != "" || getLnamediploma != "" || getMajor != "") {
                    c4 = " AND ";
                }
                if (getDegree != "") {
                    degree = "degree = " + "'"
                            + request.getParameter("degree") + "'";
                }
            }

            //Year Checkbox
            if (request.getParameter("check_years") != null) {
                if (getFname != "" || getLname != "" || getLnamediploma != "" || getMajor != "" || getDegree != "") {
                    c5 = " AND ";
                } else {
                    c5 = "";
                }
                if (getYear1 != "" && getYear2 != "") {
                    year = "graduation_year BETWEEN " + "'"
                            + request.getParameter("year1") + "' AND '"
                            + request.getParameter("year2") + "'";
                }
            }

            String testSQL = "SELECT * FROM user_t "
                    + "WHERE " + fname + c1
                    + lname + c2 + lnamediploma + c3 + major + c4 + degree + c5 + year;

            ArrayList<User> users = UserDB.searchTest(testSQL);
            
            request.setAttribute("users", users);
            url = "/home/search.jsp";

        } else if (action.equals("view_alumni")) {
            // get
            String ID = request.getParameter("id");
            Long userID = Long.parseLong(ID);
            
            User user = (User) session.getAttribute("user");
            Long id = user.getId();

            user = UserDB.selectUser(id);
            User request_user = UserDB.selectUser(userID);
            
            Boolean network = RelationshipDB.networkExists(user, request_user);
            String message = null;
            if (network) {

            User view_user = UserDB.selectUser(userID);
            Personal view_personal = PersonalDB.selectUser(userID);
            Diplomas view_diplomas = DiplomasDB.selectUser(userID);
            Employment view_employment = EmploymentDB.selectUser(userID);
            Skills view_skills = SkillsDB.selectUser(userID);
            if (view_skills == null) {
                String SkillsValues = "";
                request.setAttribute("view_skills", SkillsValues);
            } else {
                String SkillsValues = view_skills.getSkills();
                request.setAttribute("view_skills", SkillsValues);
            }

            request.setAttribute("view_user", view_user);
            request.setAttribute("view_personal", view_personal);
            request.setAttribute("view_diplomas", view_diplomas);
            request.setAttribute("view_employment", view_employment);

            url = "/home/view_friend_info.jsp";
            } else {
                message = "Sorry, an Alumni Network does not exists.";
                url = "/home/search.jsp";
            }
            request.setAttribute("message", message);
            

        } else if (action.equals("add_alumni")) {
            // get

            User user = (User) session.getAttribute("user");
            
            String ID = request.getParameter("id");
            Long userID = Long.parseLong(ID);

            User user_two = UserDB.selectUser(userID);
            
            RelationshipDB.insert(user, user_two);
            
            url = "/home/search.jsp";
        }

        getServletContext()
                .getRequestDispatcher(url)
                .forward(request, response);
        
    }

    @Override
    protected void doGet(HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {
        doPost(request, response);
    }

}
