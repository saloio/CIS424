/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package alumni.controllers;

import alumni.business.Diplomas;
import alumni.business.Employment;
import alumni.business.Personal;
import alumni.business.Skills;
import alumni.business.User;
import alumni.data.DiplomasDB;
import alumni.data.EmploymentDB;
import alumni.data.PersonalDB;
import alumni.data.RelationshipDB;
import alumni.data.SkillsDB;
import alumni.data.UserDB;
import alumni.util.CookieUtil;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Sandro
 */
public class NetworkServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession();

        String url = "/home/networks.jsp";

        // get current action
        String action = request.getParameter("action");
        if (action == null) {
            action = "view";  // default action
        }

        // perform action and set URL to appropriate page
        if (action.equals("view")) {
            // get list of users
        User user = (User) session.getAttribute("user");

        // if the User object doesn't exist, check for the email cookie
        if (user == null) {
            Cookie[] cookies = request.getCookies();
            String emailAddress
                    = CookieUtil.getCookieValue(cookies, "emailCookie");
            // if the email cookie doesn't exist, go to the registration page
            if (emailAddress == null || emailAddress.equals("")) {
                url = "/index.jsp";
            } else {
                user = UserDB.selectUser(emailAddress);
                // if a user for that email isn't in the database, 
                // go to the registration page
                if (user == null) {
                    url = "/index.jsp";
                }
                session.setAttribute("user", user);
            }
        }
        String ID = request.getParameter("id");
        Long userID = Long.parseLong(ID);
        User profileUserID = UserDB.selectUser(userID);

        ArrayList<User> networks = RelationshipDB.networkList_one(profileUserID);
        ArrayList<User> networksTwo = RelationshipDB.networkList_two(profileUserID);
        
        networks.addAll(networksTwo);
        
        request.setAttribute("networks", networks);


            url = "/home/networks.jsp";
        
        } 

        getServletContext()
                .getRequestDispatcher(url)
                .forward(request, response);
        
    }

    @Override
    protected void doGet(HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {
        doPost(request, response);
    }

}
