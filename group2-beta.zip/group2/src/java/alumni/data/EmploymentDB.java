/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package alumni.data;

import java.sql.*;

import alumni.business.*;

public class EmploymentDB {

    public static long insert(Employment employment) {
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;

        String query = "INSERT INTO employment_t "
                + "(UserID, workphone, position, employer) "
                + "VALUES "
                + "(?, ?, ?, ?)";
        try {
            ps = connection.prepareStatement(query);
            ps.setLong(1, employment.getUser().getId());
            ps.setString(2, employment.getWorkphone());
            ps.setString(3, employment.getPosition());
            ps.setString(4, employment.getEmployer());
            return ps.executeUpdate();
        } catch (SQLException e) {
            System.err.println(e);
            return 0;
        } finally {
            DBUtil.closeResultSet(rs);
            DBUtil.closePreparedStatement(ps);
            pool.freeConnection(connection);
        }
    }

    public static void update(Employment employment) {
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;

        String query = "UPDATE employment_t SET "
                + "workphone = ?, "
                + "employer = ?, "
                + "position = ? "
                + "WHERE userID = ? ";
        try {
            ps = connection.prepareStatement(query);
            ps.setString(1, employment.getWorkphone());
            ps.setString(2, employment.getEmployer());
            ps.setString(3, employment.getPosition());
            ps.setLong(4, employment.getUser().getId());
            ps.executeUpdate();
        } catch (SQLException e) {
            System.err.println(e);
        } finally {
            DBUtil.closeResultSet(rs);
            DBUtil.closePreparedStatement(ps);
            pool.freeConnection(connection);
        }
    }

    public static boolean EmployerExists(Long userID) {
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;

        String query = "SELECT userID FROM employment_t "
                + "WHERE userID = ?";
        try {
            ps = connection.prepareStatement(query);
            ps.setLong(1, userID);
            rs = ps.executeQuery();
            return rs.next();
        } catch (SQLException e) {
            System.err.println(e);
            return false;
        } finally {
            DBUtil.closeResultSet(rs);
            DBUtil.closePreparedStatement(ps);
            pool.freeConnection(connection);
        }
    }

    public static Employment selectUser(Long userID) {
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;

        String query = "SELECT * FROM employment_t "
                + "WHERE userID = ?";
        try {
            ps = connection.prepareStatement(query);
            ps.setLong(1, userID);
            rs = ps.executeQuery();
            Employment employment = null;
            if (rs.next()) {
                employment = new Employment();
                employment.setId(rs.getLong("userID"));
                employment.setWorkphone(rs.getString("workphone"));
                employment.setEmployer(rs.getString("employer"));
                employment.setPosition(rs.getString("position"));
            }
            return employment;
        } catch (SQLException e) {
            System.out.println(e);
            return null;
        } finally {
            DBUtil.closeResultSet(rs);
            DBUtil.closePreparedStatement(ps);
            pool.freeConnection(connection);
        }
    }
}
