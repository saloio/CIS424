package alumni.data;

/**
 *
 * @author Sandro
 */
import java.sql.*;
import alumni.business.*;

public class SkillsDB {

    public static void insert(Skills skills) {
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;

        String query
                = "INSERT INTO skills_t (UserID, skills) "
                + "VALUES (?, ?)";
        try {
            ps = connection.prepareStatement(query);
            ps.setLong(1, skills.getUser().getId());
            ps.setString(2, skills.getSkills());
            
            ps.executeUpdate();

        } catch (SQLException e) {
            System.out.println(e);

        } finally {
            DBUtil.closeResultSet(rs);
            DBUtil.closePreparedStatement(ps);
            pool.freeConnection(connection);
        }
    }
    
    public static void update(Skills skills) {
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;

        String query = "UPDATE skills_t SET "
                + "skills = ? "
                + "WHERE userID = ? ";
        try {
            ps = connection.prepareStatement(query);
            ps.setString(1, skills.getSkills());
            ps.setLong(2, skills.getUser().getId());
            ps.executeUpdate();
        } catch (SQLException e) {
            System.err.println(e);
        } finally {
            DBUtil.closeResultSet(rs);
            DBUtil.closePreparedStatement(ps);
            pool.freeConnection(connection);
        }
    }    
    
    public static boolean SkillsExists(Long userID) {
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;

        String query = "SELECT userID FROM skills_t "
                + "WHERE userID = ?";
        try {
            ps = connection.prepareStatement(query);
            ps.setLong(1, userID);
            rs = ps.executeQuery();
            return rs.next();
        } catch (SQLException e) {
            System.err.println(e);
            return false;
        } finally {
            DBUtil.closeResultSet(rs);
            DBUtil.closePreparedStatement(ps);
            pool.freeConnection(connection);
        }
    }    
    
    public static Skills selectUser(Long userID) {
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;

        String query = "SELECT * FROM skills_t "
                + "WHERE userID = ?";
        try {
            ps = connection.prepareStatement(query);
            ps.setLong(1, userID);
            rs = ps.executeQuery();
            Skills skills = null;
            if (rs.next()) {
                skills = new Skills();
                skills.setId(rs.getLong("userID"));
                skills.setSkills(rs.getString("skills"));

            }
            return skills;
        } catch (SQLException e) {
            System.out.println(e);
            return null;
        } finally {
            DBUtil.closeResultSet(rs);
            DBUtil.closePreparedStatement(ps);
            pool.freeConnection(connection);
        }
    }    
}