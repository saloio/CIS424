/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package alumni.controllers;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

/**
 *
 * @author Sandro
 */
import alumni.business.*;
import alumni.data.*;

public class RegisterServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {
        String url = "/index.html";
        
        // get current action
        String action = request.getParameter("action");
        if (action == null) {
            action = "join";  // default action
        }

        // perform action and set URL to appropriate page
        if (action.equals("join")) {
            url = "/signup.jsp";    // the "join" page
        } 
        else if (action.equals("add")) {
            // get parameters from the request
            String fname = request.getParameter("fname");
            String lname = request.getParameter("lname");
            String lnamediploma = request.getParameter("lnamediploma");            
            String email = request.getParameter("email");
            String password = request.getParameter("password");
            int year = Integer.parseInt(request.getParameter("year"));
            String degree = request.getParameter("degree");
            String major = request.getParameter("major");

            // store data in User object
            User user = new User(fname, lname, lnamediploma, email, password, year, major, degree);

            // validate the parameters
            String message;
            if (UserDB.emailExists(user.getEmail())) {
                message = "This email address already exists.<br>" +
                          "Please enter another email address.";
                url = "/signup.jsp";
            }
            else {
                message = "";
                url = "/thanks.jsp";
                UserDB.insert(user);
            }
            request.setAttribute("user", user);
            request.setAttribute("message", message);
        }
        getServletContext()
                .getRequestDispatcher(url)
                .forward(request, response);
    }    
}