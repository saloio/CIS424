/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package alumni.controllers;

import alumni.business.Diplomas;
import alumni.business.Employment;
import alumni.business.Personal;
import alumni.business.Skills;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

import alumni.business.User;
import alumni.data.*;
import java.util.ArrayList;

public class SearchServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession();

        String url = "/home/search.jsp";

        // get current action
        String action = request.getParameter("action");
        if (action == null) {
            action = "search_users";  // default action
        }

        // perform action and set URL to appropriate page
        if (action.equals("search_users")) {
            // get list of users
            String fname = request.getParameter("fname");
            String lname = request.getParameter("lname");
            String lnamediploma = request.getParameter("lnamediploma");
            String major = request.getParameter("major");
            String degree = request.getParameter("degree");
            String year1 = request.getParameter("year1");
            String year2 = request.getParameter("year2");

            String[] sqlArray = {fname, lname, lnamediploma, major, degree, year1, year2};
            String message = "";
            ArrayList<User> users = UserDB.findUsers(sqlArray);
            request.setAttribute("users", users);
            request.setAttribute("message", message);
            url = "/home/search.jsp";

        } else if (action.equals("view_alumni")) {
            // get
            String ID = request.getParameter("id");
            Long userID = Long.parseLong(ID);
            
            User user = (User) session.getAttribute("user");
            Long id = user.getId();

            user = UserDB.selectUser(id);
            User request_user = UserDB.selectUser(userID);
            
            Boolean network = RelationshipDB.networkExists(user, request_user);
            String message = null;
            if (network) {

            User view_user = UserDB.selectUser(userID);
            Personal view_personal = PersonalDB.selectUser(userID);
            Diplomas view_diplomas = DiplomasDB.selectUser(userID);
            Employment view_employment = EmploymentDB.selectUser(userID);
            Skills view_skills = SkillsDB.selectUser(userID);
            if (view_skills == null) {
                String SkillsValues = "";
                request.setAttribute("view_skills", SkillsValues);
            } else {
                String SkillsValues = view_skills.getSkills();
                request.setAttribute("view_skills", SkillsValues);
            }

            request.setAttribute("view_user", view_user);
            request.setAttribute("view_personal", view_personal);
            request.setAttribute("view_diplomas", view_diplomas);
            request.setAttribute("view_employment", view_employment);

            url = "/home/view_friend_info.jsp";
            } else {
                message = "Sorry, an Alumni Network does not exists.";
                url = "/home/search.jsp";
            }
            request.setAttribute("message", message);
            

        } else if (action.equals("add_alumni")) {
            // get

            User user = (User) session.getAttribute("user");
            
            String ID = request.getParameter("id");
            Long userID = Long.parseLong(ID);

            User user_two = UserDB.selectUser(userID);
            
            RelationshipDB.insert(user, user_two);
            
            url = "/home/search.jsp";
        }

        getServletContext()
                .getRequestDispatcher(url)
                .forward(request, response);
        
    }

    @Override
    protected void doGet(HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {
        doPost(request, response);
    }

}
