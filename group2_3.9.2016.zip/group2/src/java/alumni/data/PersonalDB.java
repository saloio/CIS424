/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package alumni.data;

import java.sql.*;

import alumni.business.*;
import java.io.InputStream;

public class PersonalDB {

    public static long insert(Personal personal) {
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;

        String query = "INSERT INTO personal_t "
                + "(UserID, cellphone, self_description) "
                + "VALUES "
                + "(?, ?, ?)";
        try {
            ps = connection.prepareStatement(query);
            ps.setLong(1, personal.getUser().getId());
            ps.setString(2, personal.getCellphone());
            ps.setString(3, personal.getSelf_description());
            return ps.executeUpdate();
        } catch (SQLException e) {
            System.err.println(e);
            return 0;
        } finally {
            DBUtil.closeResultSet(rs);
            DBUtil.closePreparedStatement(ps);
            pool.freeConnection(connection);
        }
    }

    public static long insertPhoto(Personal personal) {
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;

        String query = "INSERT INTO photos_t "
                + "(UserID, photos) "
                + "VALUES "
                + "(?, ?)";
        try {
            ps = connection.prepareStatement(query);
            ps.setLong(1, personal.getUser().getId());
            ps.setBlob(2, personal.getPhotos());
            return ps.executeUpdate();
        } catch (SQLException e) {
            System.err.println(e);
            return 0;
        } finally {
            DBUtil.closeResultSet(rs);
            DBUtil.closePreparedStatement(ps);
            pool.freeConnection(connection);
        }
    }

    public static Personal selectPhotos(Long userID) {
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;

        String query = "SELECT * FROM photos_t "
                + "WHERE userID = ?";
        try {
            ps = connection.prepareStatement(query);
            ps.setLong(1, userID);
            rs = ps.executeQuery();
            Personal personal = null;
            if (rs.next()) {
                personal = new Personal();
                personal.setId(rs.getLong("userID"));
                personal.setPhotos((InputStream) rs.getBlob("photos"));
            }
            return personal;
        } catch (SQLException e) {
            System.out.println(e);
            return null;
        } finally {
            DBUtil.closeResultSet(rs);
            DBUtil.closePreparedStatement(ps);
            pool.freeConnection(connection);
        }
    }

    public static void update(Personal personal) {
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;

        String query = "UPDATE personal_t SET "
                + "cellphone = ?, "
                + "self_description = ? "
                + "WHERE userID = ? ";
        try {
            ps = connection.prepareStatement(query);
            ps.setString(1, personal.getCellphone());
            ps.setString(2, personal.getSelf_description());
            ps.setLong(3, personal.getUser().getId());
            ps.executeUpdate();
        } catch (SQLException e) {
            System.err.println(e);
        } finally {
            DBUtil.closeResultSet(rs);
            DBUtil.closePreparedStatement(ps);
            pool.freeConnection(connection);
        }
    }

    public static boolean PersonalExists(Long userID) {
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;

        String query = "SELECT userID FROM personal_t "
                + "WHERE userID = ?";
        try {
            ps = connection.prepareStatement(query);
            ps.setLong(1, userID);
            rs = ps.executeQuery();
            return rs.next();
        } catch (SQLException e) {
            System.err.println(e);
            return false;
        } finally {
            DBUtil.closeResultSet(rs);
            DBUtil.closePreparedStatement(ps);
            pool.freeConnection(connection);
        }
    }

    public static Personal selectUser(Long userID) {
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;

        String query = "SELECT * FROM personal_t "
                + "WHERE userID = ?";
        try {
            ps = connection.prepareStatement(query);
            ps.setLong(1, userID);
            rs = ps.executeQuery();
            Personal personal = null;
            if (rs.next()) {
                personal = new Personal();
                personal.setId(rs.getLong("userID"));
                personal.setCellphone(rs.getString("cellphone"));
                personal.setSelf_description(rs.getString("self_description"));
            }
            return personal;
        } catch (SQLException e) {
            System.out.println(e);
            return null;
        } finally {
            DBUtil.closeResultSet(rs);
            DBUtil.closePreparedStatement(ps);
            pool.freeConnection(connection);
        }
    }
}
