package alumni.data;

/**
 *
 * @author Sandro
 */
import java.sql.*;
import alumni.business.*;

public class DiplomasDB {

    public static void insert(Diplomas diplomas) {
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;

        String query
                = "INSERT INTO diplomas_t (UserID, graduation_year, degree, major) "
                + "VALUES (?, ?, ?, ?)";
        try {
            ps = connection.prepareStatement(query);
            ps.setLong(1, diplomas.getUser().getId());
            ps.setInt(2, diplomas.getYear());
            ps.setString(3, diplomas.getDegree());
            ps.setString(4, diplomas.getMajor());
            
            ps.executeUpdate();

        } catch (SQLException e) {
            System.out.println(e);

        } finally {
            DBUtil.closeResultSet(rs);
            DBUtil.closePreparedStatement(ps);
            pool.freeConnection(connection);
        }
    }
    
    public static Diplomas selectUser(Long userID) {
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;

        String query = "SELECT * FROM diplomas_t "
                + "WHERE userID = ?";
        try {
            ps = connection.prepareStatement(query);
            ps.setLong(1, userID);
            rs = ps.executeQuery();
            Diplomas diplomas = null;
            if (rs.next()) {
                diplomas = new Diplomas();
                diplomas.setId(rs.getLong("userID"));
                diplomas.setYear(rs.getInt("graduation_year"));
                diplomas.setMajor(rs.getString("major"));
                diplomas.setDegree(rs.getString("degree"));
            }
            return diplomas;
        } catch (SQLException e) {
            System.out.println(e);
            return null;
        } finally {
            DBUtil.closeResultSet(rs);
            DBUtil.closePreparedStatement(ps);
            pool.freeConnection(connection);
        }
    }    
}