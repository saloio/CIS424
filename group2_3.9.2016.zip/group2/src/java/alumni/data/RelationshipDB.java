/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package alumni.data;

import alumni.business.User;
import java.sql.*;

/**
 *
 * @author Sandro
 */
public class RelationshipDB {

    public static void insert(User user_one, User user_two) {
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;

        String query
                = "INSERT INTO relationship_t (user_one_id, user_two_id) "
                + "VALUES (?, ?)";
        try {
            ps = connection.prepareStatement(query);
            ps.setLong(1, user_one.getId());
            ps.setLong(2, user_two.getId());

            ps.executeUpdate();

        } catch (SQLException e) {
            System.out.println(e);

        } finally {
            DBUtil.closeResultSet(rs);
            DBUtil.closePreparedStatement(ps);
            pool.freeConnection(connection);
        }
    }

    public static void acceptNetwork(User user_one, User user_two) {
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;

        String query
                = "UPDATE relationship_t SET "
                + "status = '1' "
                + "WHERE (user_one_id = ? OR user_two_id = ? ) "
                + "AND "
                + "(user_one_id = ? OR user_two_id = ? )";
        try {
            ps = connection.prepareStatement(query);
            ps.setLong(1, user_one.getId());
            ps.setLong(2, user_one.getId());
            ps.setLong(3, user_two.getId());
            ps.setLong(4, user_two.getId());
            ps.executeUpdate();

        } catch (SQLException e) {
            System.out.println(e);

        } finally {
            DBUtil.closeResultSet(rs);
            DBUtil.closePreparedStatement(ps);
            pool.freeConnection(connection);
        }
    }

    public static void declineNetwork(User user_one, User user_two) {
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;

        String query
                = "UPDATE relationship_t SET "
                + "status = '2' "
                + "WHERE (user_one_id = ? OR user_two_id = ? ) "
                + "AND "
                + "(user_one_id = ? OR user_two_id = ? )";
        try {
            ps = connection.prepareStatement(query);
            ps.setLong(1, user_one.getId());
            ps.setLong(2, user_one.getId());
            ps.setLong(3, user_two.getId());
            ps.setLong(4, user_two.getId());
            ps.executeUpdate();

        } catch (SQLException e) {
            System.out.println(e);

        } finally {
            DBUtil.closeResultSet(rs);
            DBUtil.closePreparedStatement(ps);
            pool.freeConnection(connection);
        }
    }

    public static User checkRequest(Long userID) {
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;

        String query = "SELECT * FROM relationship_t "
                + "WHERE ( user_two_id = ? )"
                + "AND status = '0'";
        try {
            ps = connection.prepareStatement(query);
            ps.setLong(1, userID);
            rs = ps.executeQuery();
            User user = null;
            if (rs.next()) {
                user = new User();
                user.setId(rs.getLong("user_two_id"));
                user.setFriendUserID(rs.getLong("user_one_id"));
                user.setStatus(rs.getInt("status"));
            }
            return user;
        } catch (SQLException e) {
            System.out.println(e);
            return null;
        } finally {
            DBUtil.closeResultSet(rs);
            DBUtil.closePreparedStatement(ps);
            pool.freeConnection(connection);
        }
    }
    
    public static boolean networkExists(User user_one, User user_two) {
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;

        String query
                = "SELECT * FROM relationship_t "
                + "WHERE (user_one_id = ? OR user_two_id = ? ) "
                + "AND "
                + "(user_one_id = ? OR user_two_id = ? ) "
                + "AND status = '1' ";
        try {
            ps = connection.prepareStatement(query);
            ps.setLong(1, user_one.getId());
            ps.setLong(2, user_one.getId());
            ps.setLong(3, user_two.getId());
            ps.setLong(4, user_two.getId());
            rs = ps.executeQuery();
            return rs.next();
        } catch (SQLException e) {
            System.out.println(e);
            return false;
        } finally {
            DBUtil.closeResultSet(rs);
            DBUtil.closePreparedStatement(ps);
            pool.freeConnection(connection);
        }
    }    
}
