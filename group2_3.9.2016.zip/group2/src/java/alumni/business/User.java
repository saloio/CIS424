/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package alumni.business;

/**
 *
 * @author Sandro
 */
import java.io.Serializable;

public class User implements Serializable {

    private Long userID;
    private String fname;
    private String lname;
    private String lnamediploma;
    private String email;
    private String password;
    private int graduation_year;
    private String major;
    private String degree;
    private Long friendUserID;
    private int status;

    public User() {
        email = "";
        password= "";
        fname = "";
        lname = "";
        lnamediploma = "";
        major = "";
        degree = "";
        graduation_year = 0;  
        status = 0;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }
    
    public Long getFriendUserID() {
        return friendUserID;
    }

    public void setFriendUserID(Long friendUserID) {
        this.friendUserID = friendUserID;
    }

    public User(String fname, String lname, String lnamediploma, String email, String password, int graduationYear, String major, String degree) {
        this.fname = fname;
        this.lname = lname;
        this.lnamediploma = lnamediploma;
        this.email = email;
        this.password = password;
        this.graduation_year = graduationYear;
        this.major = major;
        this.degree = degree;
    }

    public User(String email, String password) {
        this.email = email;
        this.password = password;
    }

    public User(String email) {
        this.email = email;
    }

    public int getGraduation_year() {
        return graduation_year;
    }

    public void setGraduation_year(int graduation_year) {
        this.graduation_year = graduation_year;
    }

    public String getMajor() {
        return major;
    }

    public void setMajor(String major) {
        this.major = major;
    }

    public String getDegree() {
        return degree;
    }

    public void setDegree(String degree) {
        this.degree = degree;
    }

    public Long getId() {
        return userID;
    }

    public void setId(Long userID) {
        this.userID = userID;
    }

    public String getFname() {
        return fname;
    }

    public void setFname(String fname) {
        this.fname = fname;
    }

    public String getLname() {
        return lname;
    }

    public void setLname(String lname) {
        this.lname = lname;
    }

    public String getLnamediploma() {
        return lnamediploma;
    }

    public void setLnamediploma(String lnamediploma) {
        this.lnamediploma = lnamediploma;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

}
