/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package alumni.business;

/**
 *
 * @author Sandro
 */
import java.io.Serializable;

public class Diplomas implements Serializable {

    private User user;
    private Long userId;    
    private String major;
    private String degree;
    private int year;


    public Diplomas() {
        user = null;
        major = "";
        degree = "";
        year = 0;
    }
    
    public Diplomas(int year, String degree, String major) {
        this.year = year;
        this.degree = degree;
        this.major = major;
    }
    

    public Long getId() {
        return userId;
    }

    public void setId(Long userId) {
        this.userId = userId;
    }    

    public void setUser(User user) {
        this.user = user;
    }

    public User getUser() {
        return user;
    }    

    public String getMajor() {
        return major;
    }

    public void setMajor(String major) {
        this.major = major;
    }

    public String getDegree() {
        return degree;
    }

    public void setDegree(String degree) {
        this.degree = degree;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

}
