/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package alumni.controllers;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

/**
 *
 * @author Sandro
 */
import alumni.business.*;
import alumni.data.*;

public class LoginServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession();
        String url = "/index.html";

        // get current action
        String action = request.getParameter("action");
        if (action == null) {
            action = "join";  // default action
        }

        // perform action and set URL to appropriate page
        if (action.equals("join")) {
            url = "/signup.jsp";    // the "join" page
        } else if (action.equals("login")) {
            // get parameters from the request
            String email = request.getParameter("email");
            String password = request.getParameter("password");

            // validate the parameters
            if (UserDB.userExists(email, password)) {
                // store data in User object
                User user = UserDB.selectUser(email);
                Long userID = user.getId();
                Personal personal = PersonalDB.selectUser(userID);
                Diplomas diplomas = DiplomasDB.selectUser(userID);
                Employment employment = EmploymentDB.selectUser(userID);
                Skills skills = SkillsDB.selectUser(userID);
                
                session.setAttribute("user", user);
                session.setAttribute("personal", personal);
                session.setAttribute("diplomas", diplomas);
                session.setAttribute("employment", employment);
                session.setAttribute("skills", skills);
                
                url = "/redirect.html";
            } else {
                url = "/login_error.html";
            }
            //           request.setAttribute("user", user);

            Cookie emailCookie = new Cookie("emailCookie", email);
            emailCookie.setMaxAge(-1);
            emailCookie.setPath("/");
            response.addCookie(emailCookie);
        }
        getServletContext()
                .getRequestDispatcher(url)
                .forward(request, response);
    }

    @Override
    public void doGet(HttpServletRequest request,
            HttpServletResponse response)
            throws IOException, ServletException {

        String url = "/index.html";

        // get current action
        String action = request.getParameter("action");
        if (action == null) {
            action = "join";  // default action
        }

        // perform action and set URL to appropriate page
        if (action.equals("join")) {
            url = "/signup.jsp";    // the "join" page
        } else if (action.equals("logout")) {
            url = logout(request, response);
        }

        // forward to the view
        getServletContext()
                .getRequestDispatcher(url)
                .forward(request, response);
    }

    private String logout(HttpServletRequest request,
            HttpServletResponse response) {

        Cookie[] cookies = request.getCookies();
        for (Cookie cookie : cookies) {
            cookie.setMaxAge(0); //delete the cookie
            cookie.setPath("/"); //allow the alumni application to access it
            response.addCookie(cookie);
        }
        String url = "/index.html";
        return url;
    }
}