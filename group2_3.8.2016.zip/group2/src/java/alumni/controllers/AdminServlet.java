/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package alumni.controllers;

import java.io.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;

import alumni.business.User;
import alumni.data.UserDB;

public class AdminServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession();

        String url = "/admin/index.jsp";

        // get current action
        String action = request.getParameter("action");
        if (action == null) {
            action = "display_users";  // default action
        }

        // perform action and set URL to appropriate page
        if (action.equals("display_users")) {
            // get list of users
            String emailAddress = request.getParameter("email");
            User user = UserDB.selectUser(emailAddress);
            request.setAttribute("user", user);
            url = "/admin/index.jsp";
        } else if (action.equals("display_update")) {
            String emailAddress = request.getParameter("email");
            User userUpdate = UserDB.selectUser(emailAddress);
            session.setAttribute("userUpdate", userUpdate);
            url = "/admin/user.jsp";
        } else if (action.equals("update_user")) {
            // get parameters from the request
            String password = request.getParameter("password");

            // get and update user
            User user = (User) session.getAttribute("userUpdate");
            user.setPassword(password);
            UserDB.updatePass(user);
            request.setAttribute("user", user);

        } else if (action.equals("delete_user")) {
            // get the user
            String email = request.getParameter("email");
            User userDelete = UserDB.selectUser(email);

            // delte the user
            UserDB.delete(userDelete);
            
            User user = UserDB.selectUser(email);
            request.setAttribute("user", user);
        }

        getServletContext()
                .getRequestDispatcher(url)
                .forward(request, response);
    }

    @Override
    protected void doGet(HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {
        doPost(request, response);
    }

}
